#ifndef UTIL_H
#define UTIL_H

#define ERROR -32000
#define LEFT 0
#define RIGHT 0

#endif //UTIL_H