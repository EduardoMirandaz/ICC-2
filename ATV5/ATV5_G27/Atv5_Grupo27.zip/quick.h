#ifndef QUICK_H
#define QUICK_H

int _quick(int *vetor, int inicio, int fim, int *operacoesQuick);
#endif //quick