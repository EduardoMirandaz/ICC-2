#ifndef shell
#define shell

int shellSort(int vetorCopia[], int n);

#endif //shell
