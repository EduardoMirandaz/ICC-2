#ifndef QUICK_H
#define QUICK_H

void quick_Sort(int *arr, int size);
void quick(int *arr, int first, int last);

#endif //quick_H