#include "Hash.h"

struct numero
{
    int chaveIndex;
    int valor;
};

NUMERO *tabela_criar(int capacidadeTabela)
{
    NUMERO *tabela = (NUMERO *) calloc(capacidadeTabela, sizeof(NUMERO));
    return tabela;
}

NUMERO *tabela_zerar(NUMERO *tabela, int capacidadeTabela)
{
    for(int i = 0; i < capacidadeTabela; i++)
    {
        tabela[i].valor = lugar_vazio;
        tabela[i].chaveIndex = lugar_vazio;  
    }
    return tabela; 
}

int funcaoHash(int valorASerInserido, int capacidade)
{
  return valorASerInserido % capacidade;
}

void inserirNaTabela(int valorASerInserido, int capacidade, NUMERO *vetor)
{  
    for(int i = 0; i < capacidade; i++)
    {
        if(vetor[i].valor == valorASerInserido) return;
    }
    int sondagem = funcaoHash(valorASerInserido, capacidade);
    int i = 0;  
    while(vetor[sondagem].valor != lugar_vazio)
    {
        i++;
        sondagem = funcaoHash(valorASerInserido + i, capacidade);
    }
    vetor[sondagem].valor = valorASerInserido;
    vetor[sondagem].chaveIndex = sondagem;
}

void buscarNaTabela(int valorASerBuscado, int capacidade, NUMERO * vetor)
{
    for (int i=0; i<capacidade; i++) 
    {
        if (vetor[i].valor == valorASerBuscado) 
        {
            printf("%d ", vetor[i].chaveIndex);
            return;
        }
    }
    printf("-1 ");
}

void deletarDaTabela(int valorASerBuscado, int capacidade, NUMERO *vetor)
{
    for (int i=0; i<capacidade; i++) 
    {
        if (vetor[i].valor == valorASerBuscado) 
        {
            vetor[i].valor = lugar_vazio;
            vetor[i].chaveIndex = lugar_vazio;
            return;
        }
    }
}

void imprimirTabela(NUMERO *vetor, int tam)
{
    printf("\n");
    for(int i = 0; i < tam; i++)
    {
        printf("%d | ", vetor[i].valor);
    }
     printf("\n");
}