#ifndef HASH_H
#define HASH_H
#include <stdio.h>
#include <stdlib.h>

typedef struct numero NUMERO;
#define ERRO -32000
#define prinft printf
#define lugar_vazio -1

NUMERO *tabela_criar(int capacidadeTabela);

NUMERO *tabela_zerar(NUMERO *tabela, int capacidadeTabela);

int funcaoHash(int valorASerInserido, int capacidade);

void inserirNaTabela(int valorASerInserido, int capacidade, NUMERO *vetor);

void buscarNaTabela(int valorASerBuscado, int capacidade, NUMERO * vetor);

void deletarDaTabela(int valorASerBuscado, int capacidade, NUMERO *vetor);

void imprimirTabela(NUMERO *vetor, int tam);

#endif //HASH_H